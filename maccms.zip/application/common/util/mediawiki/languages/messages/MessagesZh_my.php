<?php
/** ‪Chinese (Malaysia)‬ (‪中文(马来西亚)‬)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'zh-sg';
