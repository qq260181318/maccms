<?php
namespace app\api\controller;
use think\Controller;
use think\Cache;
use app\common\util\Pinyin;

class Py extends Base
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {		
    		$param = input('get.');
    		echo Pinyin::get($param['wd']);
    }

}